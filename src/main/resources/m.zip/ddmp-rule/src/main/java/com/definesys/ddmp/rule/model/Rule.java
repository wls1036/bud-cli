package com.definesys.ddmp.rule.model;

import java.util.List;

/**
 * @Copyright: Shanghai Definesys Company.All rights reserved.
 * @Description:
 * @author: jianfeng.zheng
 * @since: 2019/2/27 下午6:01
 * @history: 1.2019/2/27 created by jianfeng.zheng
 *
 * 规则结构
 * 示例：
 * {
 *  "ruleName": "rule1",
 *  "ruleCode": "001",
 *  "ruleThen": {
 *  "eventCode": "001",
 *  "eventType": "standard/custom",
 *  "eventResult": "true/false",
 *  "cz": {
 *  "key1": "value1",
 *  "key2": "value2"
 *  }
 *  },
 *  "ruleElse": {
 *  "eventCode": "001",
 *  "eventType": "standard/custom",
 *  "eventResult": "true/false",
 *  "params": {
 *  "key1": "value1",
 *  "key2": "value2"
 *  }
 *  },
 *  "ruleIf": [
 *  {
 *  "conjunction": "and/or",
 *  "type": "group/clause",
 *  "from": {
 *  "type": "context/static/component/process",
 *  "componentId":"xxx",
 *  "value": ""
 *  },
 *  "to": {
 *  "type": "context/static/component/process",
 *  "componentId":"xxx",
 *  "value": ""
 *  },
 *  "condition": "eq/ne/contain....",
 *  "clauses": [
 *  {
 *  "conjuction": "and/or",
 *  "type": "group/clause",
 *  "from": {
 *  "type": "context/static",
 *  "value": ""
 *  },
 *  "to": {
 *  "type": "context/static",
 *  "value": ""
 *  },
 *  "condition": "eq/ne/contain....",
 *  "clauses": []
 *  }
 *  ]
 *  }
 *  ]
 *  }
 */
public class Rule {
    private String ruleName;
    private String ruleCode;
    private RuleEvent ruleThen;
    private RuleEvent ruleElse;
    private List<RuleClause> ruleClauses;

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getRuleCode() {
        return ruleCode;
    }

    public void setRuleCode(String ruleCode) {
        this.ruleCode = ruleCode;
    }

    public RuleEvent getRuleThen() {
        return ruleThen;
    }

    public void setRuleThen(RuleEvent ruleThen) {
        this.ruleThen = ruleThen;
    }

    public RuleEvent getRuleElse() {
        return ruleElse;
    }

    public void setRuleElse(RuleEvent ruleElse) {
        this.ruleElse = ruleElse;
    }

    public List<RuleClause> getRuleClauses() {
        return ruleClauses;
    }

    public void setRuleClauses(List<RuleClause> ruleClauses) {
        this.ruleClauses = ruleClauses;
    }
}
