package com.definesys.ddmp.rule.model;

/**
 * @Copyright: Shanghai Definesys Company.All rights reserved.
 * @Description:
 * @author: jianfeng.zheng
 * @since: 2019/2/27 下午6:26
 * @history: 1.2019/2/27 created by jianfeng.zheng
 */
public class RuleFactor {
}
