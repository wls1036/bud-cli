package com.definesys.ddmp.rule.engine.impl.drool;

import com.definesys.ddmp.rule.engine.RuleEngine;
import com.definesys.ddmp.rule.model.Rule;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @Copyright: Shanghai Definesys Company.All rights reserved.
 * @Description:
 * @author: jianfeng.zheng
 * @since: 2019/2/27 下午6:44
 * @history: 1.2019/2/27 created by jianfeng.zheng
 */
@Service
public class DroolRuleEngine implements RuleEngine {

    @Override
    public Boolean fireRule(Rule rule, Map<String, Object> params) {
        //转化为drl文件
        String drlRule = DroolRuleFileConvert.convertFromRule(rule, params);
        return true;
    }

}
