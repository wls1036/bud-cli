package com.definesys.ddmp.rule.model;

import java.util.List;

/**
 * @Copyright: Shanghai Definesys Company.All rights reserved.
 * @Description:
 * @author: jianfeng.zheng
 * @since: 2019/2/27 下午6:05
 * @history: 1.2019/2/27 created by jianfeng.zheng
 */
public class RuleClause {
    private String conjunction;
    private String type;
    private String condition;
    private RuleClauseSource from;
    private RuleClauseSource to;
    private List<RuleClause> clauses;

    public String getConjunction() {
        return conjunction;
    }

    public void setConjunction(String conjunction) {
        this.conjunction = conjunction;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public RuleClauseSource getFrom() {
        return from;
    }

    public void setFrom(RuleClauseSource from) {
        this.from = from;
    }

    public RuleClauseSource getTo() {
        return to;
    }

    public void setTo(RuleClauseSource to) {
        this.to = to;
    }

    public List<RuleClause> getClauses() {
        return clauses;
    }

    public void setClauses(List<RuleClause> clauses) {
        this.clauses = clauses;
    }
}

class RuleClauseSource {
    private String type;
    private String componentId;
    private String value;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getComponentId() {
        return componentId;
    }

    public void setComponentId(String componentId) {
        this.componentId = componentId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
