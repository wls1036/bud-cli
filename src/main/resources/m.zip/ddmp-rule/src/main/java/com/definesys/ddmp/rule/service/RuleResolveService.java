package com.definesys.ddmp.rule.service;

import com.definesys.ddmp.rule.dao.RuleDao;
import com.definesys.ddmp.rule.engine.RuleEngine;
import com.definesys.ddmp.rule.model.Rule;
import com.definesys.ddmp.rule.model.RuleEvent;
import com.definesys.mpaas.common.adapter.UserProfile;
import com.definesys.mpaas.query.session.MpaasSession;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;

/**
 * @Copyright: Shanghai Definesys Company.All rights reserved.
 * @Description:
 * @author: jianfeng.zheng
 * @since: 2019/2/27 下午6:11
 * @history: 1.2019/2/27 created by jianfeng.zheng
 */
public class RuleResolveService {


    @Autowired
    private RuleEngine ruleEngine;

    @Autowired
    private RuleDao ruleDao;


    /**
     * 验证规则
     *
     * @param ruleId
     * @param componentValues
     * @param documentId
     * @return
     */
    private RuleEvent fireRule(String ruleId, Map<String, String> componentValues, String documentId) {
        Rule rule = ruleDao.getRuleById(ruleId);
        //1.获取系统数据
        Map<String, Object> data = this.getContextData();
        //2.获取表单组件数据
        data.putAll(componentValues);
        //3.获取流程数据
        data.putAll(this.getProcessData(documentId));
        //4.规则引擎执行
        RuleEvent event = this.fireRule(rule, data);
        return null;
    }

    /**
     * 规则引擎执行
     *
     * @param rule
     * @param params
     * @return
     */
    private RuleEvent fireRule(Rule rule, Map<String, Object> params) {
        Boolean ok = ruleEngine.fireRule(rule, params);
        return ok ? rule.getRuleThen() : rule.getRuleElse();
    }


    /**
     * 获取上下文数据
     *
     * @return
     */
    private Map getContextData() {
        Map<String, Object> data = new HashMap<>();
        UserProfile profile = MpaasSession.getUserProfile();
        data.put("currentUser", profile.getUid());
        data.put("currentUserName", profile.getUserName());
        data.putAll(profile.getAttributes());
        data.put("token", profile.getToken());
        return data;
    }

    /**
     * 获取流程数据
     *
     * @param documentId
     * @return
     */
    private Map getProcessData(String documentId) {
        Map<String, Object> data = new HashMap<>();
        return data;
    }
}
