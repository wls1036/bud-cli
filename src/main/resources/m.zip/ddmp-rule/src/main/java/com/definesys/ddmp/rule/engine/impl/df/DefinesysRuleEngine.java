package com.definesys.ddmp.rule.engine.impl.df;

import com.definesys.ddmp.rule.engine.RuleEngine;
import com.definesys.ddmp.rule.model.Rule;

import java.util.Map;

/**
 * @Copyright: Shanghai Definesys Company.All rights reserved.
 * @Description:
 * @author: jianfeng.zheng
 * @since: 2019/3/1 下午2:36
 * @history: 1.2019/3/1 created by jianfeng.zheng
 */
public class DefinesysRuleEngine implements RuleEngine {
    @Override
    public Boolean fireRule(Rule rule, Map<String, Object> params) {

        return true;
    }
}
