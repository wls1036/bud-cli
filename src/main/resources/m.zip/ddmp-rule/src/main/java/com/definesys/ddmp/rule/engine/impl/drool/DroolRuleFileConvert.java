package com.definesys.ddmp.rule.engine.impl.drool;

import com.definesys.ddmp.rule.model.Rule;

import java.util.Map;

/**
 * @Copyright: Shanghai Definesys Company.All rights reserved.
 * @Description:
 * @author: jianfeng.zheng
 * @since: 2019/2/27 下午7:16
 * @history: 1.2019/2/27 created by jianfeng.zheng
 */
public class DroolRuleFileConvert {

    public static String convertFromRule(Rule rule, Map<String, Object> data) {
        return "";
    }
}
