package com.definesys.ddmp.rule.dao;

import com.definesys.ddmp.rule.model.Rule;
import org.springframework.stereotype.Component;

/**
 * @Copyright: Shanghai Definesys Company.All rights reserved.
 * @Description:
 * @author: jianfeng.zheng
 * @since: 2019/2/27 下午6:50
 * @history: 1.2019/2/27 created by jianfeng.zheng
 */

@Component
public class RuleDao {


    public Rule getRuleById(String ruleId){
        return null;
    }
}
